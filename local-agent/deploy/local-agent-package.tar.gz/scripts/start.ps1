# local-agent start script — called by watchdog or manually
# Usage: pwsh -File start.ps1
param(
    [int]$Port = 9000,
    [string]$HostAddr = "127.0.0.1"
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ProjectDir = Resolve-Path "$ScriptDir\.."
$VenvPython = "$ProjectDir\.venv\Scripts\python.exe"

if (-not (Test-Path $VenvPython)) {
    Write-Host "[start] .venv not found at $VenvPython — run 'uv sync' first"
    exit 1
}

Write-Host "[start] Launching local-agent on ${HostAddr}:${Port}..."
$env:PYTHONUNBUFFERED = "1"

# Use uv to run uvicorn with the venv
Set-Location $ProjectDir
& uv run uvicorn app.main:app --host $HostAddr --port $Port --log-level warning 2>&1
