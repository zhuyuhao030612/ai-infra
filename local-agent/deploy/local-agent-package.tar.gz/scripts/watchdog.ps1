# local-agent watchdog — keeps the server alive
# Run this at startup. It loops forever, checking health and restarting if dead.
# Usage: pwsh -File watchdog.ps1
param(
    [int]$Port = 9000,
    [string]$HostAddr = "127.0.0.1",
    [int]$CheckIntervalSec = 30
)

$ErrorActionPreference = "SilentlyContinue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$StartScript = Join-Path $ScriptDir "start.ps1"
$HealthUrl = "http://${HostAddr}:${Port}/health"
$LogFile = Join-Path $ScriptDir "..\logs\watchdog.log"

# Ensure log directory
$LogDir = Split-Path $LogFile -Parent
if (-not (Test-Path $LogDir)) { New-Item -ItemType Directory -Force -Path $LogDir | Out-Null }

function Write-Log($msg) {
    $ts = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $line = "[$ts] $msg"
    Write-Host $line
    Add-Content -Path $LogFile -Value $line
}

Write-Log "Watchdog started. Watching ${HealthUrl} every ${CheckIntervalSec}s"

$restartCount = 0
$consecutiveFailures = 0

while ($true) {
    try {
        $resp = Invoke-WebRequest -Uri $HealthUrl -UseBasicParsing -TimeoutSec 3
        if ($resp.StatusCode -eq 200) {
            if ($consecutiveFailures -gt 0) {
                Write-Log "Health OK (recovered after $consecutiveFailures failures)"
            }
            $consecutiveFailures = 0
        } else {
            $consecutiveFailures++
            Write-Log "Health returned $($resp.StatusCode) (failure #$consecutiveFailures)"
        }
    } catch {
        $consecutiveFailures++
        Write-Log "Health check failed: $_ (failure #$consecutiveFailures)"
    }

    # Restart if 2 consecutive failures
    if ($consecutiveFailures -ge 2) {
        $restartCount++
        Write-Log "RESTART #$restartCount — launching $StartScript"

        # Kill any stale python processes on our port
        $stale = Get-Process -Name "python" -ErrorAction SilentlyContinue |
            Where-Object { $_.CommandLine -match "uvicorn.*${Port}" }
        if ($stale) {
            Write-Log "Killing stale uvicorn PID $($stale.Id)"
            $stale | Stop-Process -Force
            Start-Sleep -Seconds 2
        }

        # Start new instance
        Start-Process -FilePath "pwsh" -ArgumentList "-NoLogo -File `"$StartScript`" -Port $Port -HostAddr $HostAddr" -WindowStyle Hidden

        $consecutiveFailures = 0
        Write-Log "New instance launched, waiting for it to come up..."
        Start-Sleep -Seconds 5
    }

    Start-Sleep -Seconds $CheckIntervalSec
}
