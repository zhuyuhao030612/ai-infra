"""Token-based authentication. Static tokens from .env for MVP."""
import os
from fastapi import HTTPException, Header
from dotenv import load_dotenv

load_dotenv()

AGENT_TOKEN = os.getenv("AGENT_TOKEN", "local-agent-mvp-token-change-me")
HIGH_RISK_TOKEN = os.getenv("HIGH_RISK_TOKEN", "high-risk-confirm-token-change-me")


def verify_token(authorization: str = Header("")) -> None:
    """Normal auth — required for all endpoints."""
    if not authorization:
        raise HTTPException(status_code=401, detail="Missing Authorization header")
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing or invalid Authorization header")
    token = authorization.removeprefix("Bearer ")
    if token != AGENT_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid token")


def verify_high_risk_token(x_high_risk_token: str = Header("")) -> None:
    """Extra auth — required for dangerous operations (kill, delete, exec)."""
    if not x_high_risk_token:
        raise HTTPException(status_code=401, detail="Missing X-High-Risk-Token header")
    if x_high_risk_token != HIGH_RISK_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid high-risk token")
