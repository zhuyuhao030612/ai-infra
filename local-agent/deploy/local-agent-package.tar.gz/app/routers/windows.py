"""Window info — minimal, no UIA dependency."""
import subprocess
import json
from fastapi import APIRouter, Depends

from app.schemas import APIResponse
from app.audit import new_request_id
from app.security import verify_token

router = APIRouter(tags=["windows"])


def _get_windows() -> list[dict]:
    """Get processes with visible window titles via PowerShell."""
    ps = """
[Console]::OutputEncoding = [Text.Encoding]::UTF8
$OutputEncoding = [Text.Encoding]::UTF8
Get-Process | Where-Object { $_.MainWindowTitle -and $_.MainWindowTitle.Length -gt 0 } |
    Select-Object Id, ProcessName, MainWindowTitle |
    Sort-Object ProcessName |
    ConvertTo-Json
"""
    try:
        result = subprocess.run(
            ["pwsh", "-NoLogo", "-Command", ps],
            capture_output=True, text=True, timeout=10, encoding="utf-8", errors="replace",
        )
        if result.returncode == 0 and result.stdout.strip():
            data = json.loads(result.stdout)
            if isinstance(data, dict):
                data = [data]
            return [{"pid": w.get("Id"), "process": w.get("ProcessName", ""), "title": w.get("MainWindowTitle", "")} for w in data]
    except Exception:
        pass
    return []


@router.get("/windows", response_model=APIResponse)
def list_windows(_: None = Depends(verify_token)):
    rid = new_request_id()
    wins = _get_windows()
    return APIResponse(request_id=rid, success=True, data={"windows": wins, "count": len(wins)})
