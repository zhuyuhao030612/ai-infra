"""Process management — list and kill."""
import psutil
from fastapi import APIRouter, Depends

from app.audit import audit_log, new_request_id
from app.schemas import APIResponse, ProcessKillRequest, ProcessListItem
from app.security import verify_token, verify_high_risk_token

router = APIRouter(tags=["process"])


@router.post("/process/list", response_model=APIResponse)
def list_processes(_: None = Depends(verify_token)):
    rid = new_request_id()
    items = []
    for p in psutil.process_iter(["pid", "name", "exe", "username", "status"]):
        try:
            items.append(ProcessListItem(
                pid=p.info["pid"],
                name=p.info["name"] or "",
                exe=p.info["exe"],
                username=p.info["username"],
                status=p.info["status"] or "unknown",
            ))
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    audit_log(rid, "process_list", {"count": len(items)})
    return APIResponse(request_id=rid, success=True, data={"processes": [i.model_dump() for i in items]})


@router.post("/process/kill", response_model=APIResponse)
def kill_process(
    req: ProcessKillRequest,
    _token: None = Depends(verify_token),
    _hr: None = Depends(verify_high_risk_token),
):
    rid = new_request_id()
    try:
        p = psutil.Process(req.pid)
        info = {"pid": req.pid, "name": p.name(), "exe": p.exe(), "reason": req.reason}
        audit_log(rid, "process_kill_request", info)
        p.terminate()
        p.wait(timeout=5)
        audit_log(rid, "process_kill_done", {"pid": req.pid})
        return APIResponse(request_id=rid, success=True, data={"killed": req.pid})
    except psutil.NoSuchProcess:
        return APIResponse(request_id=rid, success=False, error=f"Process {req.pid} not found")
    except psutil.AccessDenied:
        return APIResponse(request_id=rid, success=False, error=f"Access denied for PID {req.pid}")
    except Exception as e:
        audit_log(rid, "process_kill_failed", {"pid": req.pid, "error": str(e)})
        return APIResponse(request_id=rid, success=False, error=str(e))
