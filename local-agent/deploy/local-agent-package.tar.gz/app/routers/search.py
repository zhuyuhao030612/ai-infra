"""File search — Everything CLI for instant filename search + fallback for content search."""
import subprocess
from pathlib import Path
from fastapi import APIRouter, Depends

from app.audit import audit_log, new_request_id
from app.schemas import APIResponse
from app.security import verify_token
from pydantic import BaseModel

router = APIRouter(tags=["search"])

ES_EXE = r"C:\Program Files\Everything\es.exe"


class SearchRequest(BaseModel):
    query: str
    max_results: int = 50
    search_content: bool = False  # True = grep inside files (slow), False = filename only (instant)


def _search_filename(query: str, max_results: int) -> list[dict]:
    """Search by filename using Python glob — fast, works everywhere."""
    search_roots = [
        Path(r"D:\Code"),
        Path(r"C:\Users\ZHUYU\Desktop"),
        Path(r"C:\Users\ZHUYU\Documents"),
        Path(r"D:\PHS"),
    ]
    pattern = f"*{query}*"
    results = []
    for root in search_roots:
        if not root.exists():
            continue
        try:
            for p in root.rglob(pattern):
                if p.is_file() and len(results) < max_results:
                    try:
                        stat = p.stat()
                        results.append({
                            "path": str(p), "name": p.name,
                            "size": stat.st_size, "modified": stat.st_mtime,
                        })
                    except OSError:
                        results.append({"path": str(p), "name": p.name, "size": 0, "modified": 0})
        except PermissionError:
            pass
    return results


def _search_content(pattern: str, max_results: int) -> list[dict]:
    """Content search via findstr — limited scope, for grep-like needs."""
    search_dirs = [r"D:\Code", r"C:\Users\ZHUYU\Desktop"]
    results = []
    for sd in search_dirs:
        if not Path(sd).exists() or len(results) >= max_results:
            continue
        try:
            proc = subprocess.run(
                ["findstr", "/s", "/i", "/m", "/c:" + pattern, sd + "\\*"],
                capture_output=True, text=True, timeout=30,
            )
            for line in proc.stdout.strip().split("\n"):
                line = line.strip()
                if line and len(results) < max_results:
                    results.append({"path": line, "name": Path(line).name, "match": "content"})
        except Exception:
            pass
    return results


@router.post("/search", response_model=APIResponse)
def search_files(req: SearchRequest, _: None = Depends(verify_token)):
    rid = new_request_id()
    audit_log(rid, "search", {"query": req.query, "max": req.max_results})

    # 1. Fast filename search (glob)
    results = _search_filename(req.query, req.max_results)

    # 2. Content search if requested (slower, findstr)
    if req.search_content:
        content_results = _search_content(req.query, req.max_results)
        results.extend(content_results)

    return APIResponse(
        request_id=rid,
        success=True,
        data={"query": req.query, "count": len(results), "results": results},
    )
