"""Command execution — run shell commands with timeout."""
import subprocess
from fastapi import APIRouter, Depends

from app.audit import audit_log, new_request_id
from app.schemas import APIResponse, ExecRequest
from app.security import verify_token, verify_high_risk_token

router = APIRouter(tags=["exec"])


@router.post("/exec", response_model=APIResponse)
def execute_command(
    req: ExecRequest,
    _token: None = Depends(verify_token),
    _hr: None = Depends(verify_high_risk_token),
):
    rid = new_request_id()
    audit_log(rid, "exec_request", {"command": req.command, "timeout": req.timeout})
    try:
        result = subprocess.run(
            req.command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=req.timeout,
            cwd=req.working_dir or None,
        )
        audit_log(rid, "exec_done", {"exit_code": result.returncode})
        return APIResponse(
            request_id=rid,
            success=result.returncode == 0,
            data={
                "exit_code": result.returncode,
                "stdout": result.stdout[-10000:],  # cap at 10KB
                "stderr": result.stderr[-5000:],
            },
        )
    except subprocess.TimeoutExpired:
        audit_log(rid, "exec_timeout", {"command": req.command})
        return APIResponse(request_id=rid, success=False, error=f"Command timed out after {req.timeout}s")
    except Exception as e:
        audit_log(rid, "exec_failed", {"error": str(e)})
        return APIResponse(request_id=rid, success=False, error=str(e))
