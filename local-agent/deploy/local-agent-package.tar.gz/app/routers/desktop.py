"""Desktop UI automation — pyautogui for mouse/keyboard, pywinaudio for Windows native."""
import io
import base64
from pathlib import Path
from fastapi import APIRouter, Depends
import pyautogui

from app.audit import audit_log, new_request_id
from app.schemas import APIResponse
from app.security import verify_token, verify_high_risk_token
from pydantic import BaseModel

router = APIRouter(tags=["desktop"])

pyautogui.FAILSAFE = True  # Move mouse to corner (0,0) to abort
pyautogui.PAUSE = 0.1


class ScreenshotRequest(BaseModel):
    region: tuple[int, int, int, int] | None = None  # x,y,w,h or full screen


class ClickRequest(BaseModel):
    x: int
    y: int
    button: str = "left"  # left, right, middle
    clicks: int = 1


class TypeRequest(BaseModel):
    text: str
    interval: float = 0.05  # seconds between keystrokes


class WindowRequest(BaseModel):
    title_contains: str


@router.post("/desktop/screenshot", response_model=APIResponse)
def take_screenshot(req: ScreenshotRequest | None = None, _: None = Depends(verify_token)):
    rid = new_request_id()
    try:
        region = req.region if req else None
        img = pyautogui.screenshot(region=region)
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode()
        audit_log(rid, "desktop_screenshot", {"region": region})
        return APIResponse(request_id=rid, success=True, data={"format": "png", "base64": b64, "size": len(b64)})
    except Exception as e:
        return APIResponse(request_id=rid, success=False, error=str(e))


@router.post("/desktop/screenshot/file", response_model=APIResponse)
def save_screenshot_file(filename: str = "screenshot.png", _: None = Depends(verify_token)):
    """Save screenshot to D:\\Code\\screenshots\\"""
    rid = new_request_id()
    try:
        out_dir = Path("D:/Code/screenshots")
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / filename
        pyautogui.screenshot(str(path))
        audit_log(rid, "desktop_screenshot_file", {"path": str(path)})
        return APIResponse(request_id=rid, success=True, data={"path": str(path)})
    except Exception as e:
        return APIResponse(request_id=rid, success=False, error=str(e))


@router.post("/desktop/click", response_model=APIResponse)
def click(req: ClickRequest, _t: None = Depends(verify_token), _hr: None = Depends(verify_high_risk_token)):
    rid = new_request_id()
    audit_log(rid, "desktop_click", {"x": req.x, "y": req.y, "button": req.button})
    pyautogui.click(req.x, req.y, clicks=req.clicks, button=req.button)
    return APIResponse(request_id=rid, success=True, data={"clicked": f"{req.x},{req.y}"})


@router.post("/desktop/type", response_model=APIResponse)
def type_text(req: TypeRequest, _t: None = Depends(verify_token), _hr: None = Depends(verify_high_risk_token)):
    rid = new_request_id()
    audit_log(rid, "desktop_type", {"length": len(req.text)})
    pyautogui.typewrite(req.text, interval=req.interval)
    return APIResponse(request_id=rid, success=True, data={"typed": len(req.text)})


@router.post("/desktop/screen_size", response_model=APIResponse)
def screen_size(_: None = Depends(verify_token)):
    rid = new_request_id()
    w, h = pyautogui.size()
    return APIResponse(request_id=rid, success=True, data={"width": w, "height": h})


@router.post("/desktop/hotkey", response_model=APIResponse)
def hotkey(keys: str, _t: None = Depends(verify_token), _hr: None = Depends(verify_high_risk_token)):
    """Send a hotkey combo, e.g. 'ctrl+c' or 'alt+tab'"""
    rid = new_request_id()
    audit_log(rid, "desktop_hotkey", {"keys": keys})
    pyautogui.hotkey(*keys.split("+"))
    return APIResponse(request_id=rid, success=True, data={"hotkey": keys})
