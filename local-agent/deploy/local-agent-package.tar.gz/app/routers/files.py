"""File operations — read and safe-delete (Recycle Bin)."""
from pathlib import Path
from fastapi import APIRouter, Depends
import send2trash

from app.audit import audit_log, new_request_id
from app.schemas import APIResponse, FilePathRequest, FileReadResponse
from app.security import verify_token, verify_high_risk_token

router = APIRouter(tags=["files"])


@router.post("/files/read", response_model=APIResponse)
def read_file(req: FilePathRequest, _: None = Depends(verify_token)):
    rid = new_request_id()
    path = Path(req.path)
    if not path.exists():
        return APIResponse(request_id=rid, success=False, error=f"File not found: {req.path}")
    if path.is_dir():
        return APIResponse(request_id=rid, success=False, error=f"Path is a directory: {req.path}")
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
        audit_log(rid, "file_read", {"path": str(path), "size": path.stat().st_size})
        return APIResponse(
            request_id=rid,
            success=True,
            data=FileReadResponse(path=str(path), size=path.stat().st_size, content=content).model_dump(),
        )
    except Exception as e:
        return APIResponse(request_id=rid, success=False, error=str(e))


@router.post("/files/delete", response_model=APIResponse)
def delete_file(
    req: FilePathRequest,
    _token: None = Depends(verify_token),
    _hr: None = Depends(verify_high_risk_token),
):
    rid = new_request_id()
    path = Path(req.path)
    if not path.exists():
        return APIResponse(request_id=rid, success=False, error=f"File not found: {req.path}")
    try:
        audit_log(rid, "file_delete_request", {"path": str(path), "size": path.stat().st_size})
        send2trash.send2trash(str(path))
        audit_log(rid, "file_delete_done", {"path": str(path)})
        return APIResponse(request_id=rid, success=True, data={"deleted": str(path), "method": "recycle_bin"})
    except Exception as e:
        audit_log(rid, "file_delete_failed", {"path": str(path), "error": str(e)})
        return APIResponse(request_id=rid, success=False, error=str(e))
