"""Failure artifact browser — safe read-only access."""
import json
from pathlib import Path
from fastapi import APIRouter, HTTPException, Depends

from app.schemas import APIResponse
from app.audit import new_request_id
from app.security import verify_token

router = APIRouter(tags=["failures"])

FAILURES_DIR = Path("D:/Code/ai-infra/failures").resolve()
MAX_TEXT_ARTIFACT_BYTES = 1 * 1024 * 1024  # 1MB


def _safe_path(failure_id: str, artifact: str | None = None) -> Path:
    """Validate and resolve path — prevent directory traversal."""
    if ".." in failure_id or "/" in failure_id or "\\" in failure_id:
        raise HTTPException(400, "Invalid failure ID")

    base = (FAILURES_DIR / failure_id).resolve()
    if not str(base).startswith(str(FAILURES_DIR)):
        raise HTTPException(400, "Invalid path")

    if artifact is None:
        return base

    if ".." in artifact or "/" in artifact or "\\" in artifact:
        raise HTTPException(400, "Invalid artifact name")

    path = (base / artifact).resolve()
    if not str(path).startswith(str(base)):
        raise HTTPException(400, "Invalid artifact path")

    return path


@router.get("/failures/recent", response_model=APIResponse)
def recent_failures(limit: int = 10, _: None = Depends(verify_token)):
    """List recent failure directories (by modification time, descending)."""
    rid = new_request_id()
    if not FAILURES_DIR.exists():
        return APIResponse(request_id=rid, success=True, data={"failures": []})

    dirs = sorted(
        [d for d in FAILURES_DIR.iterdir() if d.is_dir()],
        key=lambda d: d.stat().st_mtime,
        reverse=True,
    )[:limit]

    result = []
    for d in dirs:
        manifest_file = d / "manifest.json"
        if manifest_file.exists():
            try:
                manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
            except json.JSONDecodeError:
                manifest = {"id": d.name, "summary": "manifest parse error"}
        else:
            manifest = {"id": d.name, "summary": "no manifest"}

        result.append({
            "id": d.name,
            "ts": manifest.get("ts"),
            "source": manifest.get("source"),
            "error_type": manifest.get("error_type"),
            "summary": manifest.get("summary"),
            "ok": manifest.get("ok"),
        })

    return APIResponse(request_id=rid, success=True, data={"failures": result})


@router.get("/failures/{failure_id}/manifest", response_model=APIResponse)
def failure_manifest(failure_id: str, _: None = Depends(verify_token)):
    rid = new_request_id()
    path = _safe_path(failure_id) / "manifest.json"
    if not path.exists():
        raise HTTPException(404, "Manifest not found")
    manifest = json.loads(path.read_text(encoding="utf-8"))
    return APIResponse(request_id=rid, success=True, data=manifest)


@router.get("/failures/{failure_id}/artifact/{name}", response_model=APIResponse)
def failure_artifact(failure_id: str, name: str, _: None = Depends(verify_token)):
    rid = new_request_id()
    path = _safe_path(failure_id, name)
    if not path.exists():
        raise HTTPException(404, f"Artifact '{name}' not found")

    # Size check
    file_size = path.stat().st_size
    if file_size > 100 * 1024 * 1024:  # 100MB hard limit
        raise HTTPException(413, "Artifact too large")

    # Binary files: return path for direct access via static mount
    if path.suffix in (".png", ".jpg", ".jpeg", ".webp"):
        return APIResponse(request_id=rid, success=True, data={"type": "image", "path": str(path), "size": file_size})

    # Text files: return content (HTML as text/plain to prevent XSS)
    try:
        if file_size > MAX_TEXT_ARTIFACT_BYTES:
            content = f"[File too large: {file_size} bytes. First {MAX_TEXT_ARTIFACT_BYTES} bytes shown.]\n\n"
            with open(path, encoding="utf-8", errors="replace") as f:
                content += f.read(MAX_TEXT_ARTIFACT_BYTES)
        else:
            content = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        raise HTTPException(500, "Cannot read artifact")
    return APIResponse(request_id=rid, success=True, data={"type": "text", "name": name, "content": content, "size": file_size})
