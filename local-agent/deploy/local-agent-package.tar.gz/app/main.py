"""Local Agent — FastAPI app entry point."""
import shutil
from pathlib import Path
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from starlette.responses import RedirectResponse
from app.audit import new_request_id, LOG_FILE, LOG_DIR
from app.schemas import APIResponse
from app.routers import process, files, exec as exec_router, desktop, search, status as status_router, windows as windows_router, failures as failures_router

app = FastAPI(title="Local Agent", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)
app.include_router(process.router)
app.include_router(files.router)
app.include_router(exec_router.router)
app.include_router(desktop.router)
app.include_router(search.router)
app.include_router(status_router.router)
app.include_router(windows_router.router)
app.include_router(failures_router.router)

# Static UI
STATIC_DIR = Path(__file__).resolve().parent.parent / "static"
STATIC_DIR.mkdir(exist_ok=True)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")

# Screenshots directory (for saved screenshot files)
SCREENSHOTS_DIR = Path("D:/Code/screenshots")
SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/screenshots", StaticFiles(directory=str(SCREENSHOTS_DIR)), name="screenshots")

# Failures directory (for artifact images)
FAILURES_DIR = Path("D:/Code/ai-infra/failures")
FAILURES_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/failures-files", StaticFiles(directory=str(FAILURES_DIR)), name="failures_files")


@app.get("/", include_in_schema=False)
def root():
    return RedirectResponse(url="/static/index.html")


@app.on_event("startup")
def rotate_logs_if_needed() -> None:
    """Rotate audit log if larger than 10 MB."""
    MAX_BYTES = 10 * 1024 * 1024
    if LOG_FILE.exists() and LOG_FILE.stat().st_size > MAX_BYTES:
        backup = LOG_DIR / f"audit-{LOG_FILE.stat().st_mtime:.0f}.jsonl"
        shutil.move(str(LOG_FILE), str(backup))


@app.get("/health", response_model=APIResponse)
def health():
    return APIResponse(request_id=new_request_id(), success=True, data={"status": "ok"})
