"""Unified API models — all responses follow the same envelope."""
from pydantic import BaseModel
from typing import Optional, Any


class APIResponse(BaseModel):
    request_id: str
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None


class ProcessKillRequest(BaseModel):
    pid: int
    reason: Optional[str] = "No reason provided"


class ProcessListItem(BaseModel):
    pid: int
    name: str
    exe: Optional[str] = None
    username: Optional[str] = None
    status: str


class FilePathRequest(BaseModel):
    path: str


class FileReadResponse(BaseModel):
    path: str
    size: int
    content: str


class ExecRequest(BaseModel):
    command: str
    timeout: int = 30
    working_dir: Optional[str] = None
